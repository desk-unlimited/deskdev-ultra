import{default as p}from"./terminal-tab-DiFPudjx.js";import"./preload-helper-ckwbz45p.js";import"./chunk-NL6KNZEE-aMulfElY.js";export{p as default};
