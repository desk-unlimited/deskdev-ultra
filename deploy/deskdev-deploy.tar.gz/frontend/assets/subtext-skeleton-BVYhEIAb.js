import{j as t}from"./chunk-NL6KNZEE-aMulfElY.js";function s(){return t.jsx("div",{className:"w-[250px] h-[20px] skeleton"})}export{s as S};
