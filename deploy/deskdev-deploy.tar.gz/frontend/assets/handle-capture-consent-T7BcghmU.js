import{d as t}from"./module-BG7DSedf.js";const o=a=>{a&&!t.has_opted_in_capturing()&&t.opt_in_capturing(),!a&&!t.has_opted_out_capturing()&&t.opt_out_capturing()};export{o as h};
