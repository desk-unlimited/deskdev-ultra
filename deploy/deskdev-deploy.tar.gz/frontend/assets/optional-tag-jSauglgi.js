import{j as t}from"./chunk-NL6KNZEE-aMulfElY.js";function r(){return t.jsx("span",{className:"text-xs text-tertiary-alt",children:"(Optional)"})}export{r as O};
