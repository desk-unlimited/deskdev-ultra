export type GetFilesResponse = string[];

export interface GetFileResponse {
  code: string;
}
