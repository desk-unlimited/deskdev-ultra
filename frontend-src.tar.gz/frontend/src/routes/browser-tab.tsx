import { BrowserPanel } from "#/components/features/browser/browser";

function Browser() {
  return <BrowserPanel />;
}

export default Browser;
