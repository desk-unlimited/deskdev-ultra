export function SubtextSkeleton() {
  return <div className="w-[250px] h-[20px] skeleton" />;
}
