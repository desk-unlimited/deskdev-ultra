export function OptionalTag() {
  return <span className="text-xs text-tertiary-alt">(Optional)</span>;
}
